<?php
	
    /**
     * Domains
     *
     * Copyright 2018 by Oene Tjeerd de Bruin <modx@oetzie.nl>
     */
    
    class DomainsDomain extends xPDOSimpleObject {}
	
?>