<?php

    /**
     * Domains
     *
     * Copyright 2018 by Oene Tjeerd de Bruin <modx@oetzie.nl>
     */
    
    require_once dirname(__DIR__) . '/domainsdomain.class.php';
    
    class DomainsDomain_mysql extends DomainsDomain {}
	
?>